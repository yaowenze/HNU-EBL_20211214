﻿Note:

1). Copy the license file "license.usr" to the installation path, for example: 
     C:/Program Files/HNUEBL/HnuEBL/license.usr

2). Visit our website, to download the manual, user guide PDF files:
     http://www.ebeam.com.cn/  

3). Feel free to email us if you have any question, or wanna offer suggestions to improve HNU-EBL:
     support@ebeam.com.cn
     jie_liu@hnu.edu.cn